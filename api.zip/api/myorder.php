<?php
//header("Access-Control-Allow-Origin: *");
//header("Content-Type: application/json; charset=UTF-8");
include('config.php');
   $uid = $_REQUEST['id'];
    $sql = $obj->runQuery("SELECT * FROM tbl_order WHERE user_id=:userid ORDER BY order_id DESC");
    $sql->execute(array(':userid' => $uid));
    $num = $sql->rowCount();
    if($num > 0){
        $categories_arr=array( "status" => "true",
          "message" => "Successfully Created !!");
        $categories_arr["records"]=array();
      while($row = $sql->fetch(PDO::FETCH_ASSOC)){      	
          extract($row);  
          if($status == '1')
          {
              $st = "Pending";
          }
          elseif($status == '2')
          {
            $st = "Deliverd";
          }
          elseif($status == '3')
          {
            $st = "Cancel";
          } 
          elseif($status == '4')
          {
            $st = "Refund Request";
          }   
          elseif($status == '5')
          {
            $st = "Refund Accept";
          }
          else{
               $st = "";
          } 
          
           if($payment_type == '1')
          {
              $pt = "Online Payment";
          }
          else{
              $pt = "Cash On Delevery";

          }
          $orderdate = date('d-m-Y',strtotime($cdate));
        
          $category_item=array(
            "orderid" => $order_id,
            "amount" => $amount,
            "shipping" => $shipping_charge,
            "total" => $t_amount,
            "paymenttype" => $pt,
            "orderdate" => $orderdate,
            "orderstatus" => $st            
        );
        array_push($categories_arr["records"], $category_item);
      }      
   // http_response_code(200); 
    echo json_encode($categories_arr);
    }
    else
    {
   // http_response_code(404); 
    echo json_encode(
        array("status" => "false","message" => "No address found.")
    );
    }
?>
