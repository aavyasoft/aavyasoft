<?php
include('config.php');
$pid = $_REQUEST['pid']; 
$qty = $_REQUEST['qty']; 
$uid = $_REQUEST['uid'];
$query = $obj->runQuery("UPDATE temp_cat SET qty=:qty WHERE p_id=:pid AND uid=:uids");
$run = $query->execute(array(':qty' => $qty,':pid' => $pid, ':uids' =>$uid)); 
if($run)
{
$msg = array(   
"status" => "true",
"message" => "Successfully Created !!"			
);     	 
//http_response_code(200);
echo json_encode($msg); 
}
else{
//http_response_code(400);
$msg = array(   
"status" => "false",
"message" => "Successfully Not Created !!"	
); 
echo json_encode($msg);
}        
    
  
