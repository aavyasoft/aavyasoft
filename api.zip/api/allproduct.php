<?php
//header("Access-Control-Allow-Origin: *");
//header("Content-Type: application/json; charset=UTF-8");
include('config.php'); 
 //$search = $_GET["term"];

  $categories_arr=array("status" => "true",
        "message" => "Successfully Created !!");
        $categories_arr["records"]=array();

  $abc = array();

$sql = $obj->runQuery("SELECT p.*,c.category,sc.sub_category from tbl_product AS p INNER JOIN tbl_category AS c ON c.cat_id=p.cat_id INNER JOIN tbl_sub_category AS sc ON sc.sub_cat_id=p.sub_cat_id WHERE p.status=:st");

$sql->execute(array(':st' => '1'));

  if ($sql->rowCount() > 0 ) {

        while($row = $sql->fetch(PDO::FETCH_ASSOC))

          {
            $size = $obj->getoneval('tbl_size','size_name','size_id',$row['size_id']);
            $abc['id'] = $row['p_id'];
            $abc['value'] = $row['product'];
            $abc['size'] = $size;
            $abc['sizedesc'] = ucfirst($row['size_desc']);
            $abc['cat'] = str_replace(' ','-',strtolower($row['product']));
           array_push($categories_arr["records"], $abc);

          }
      }

  echo json_encode($categories_arr);
  ?>
