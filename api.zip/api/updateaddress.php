<?php
include('config.php');
$aid = $_REQUEST['aid']; 
$name = $_REQUEST['name'];
$email = $_REQUEST['email'];
$mobile = $_REQUEST['mobile'];
$street = $_REQUEST['street'];
$landmark = $_REQUEST['landmark'];
$pincode = $_REQUEST['pincode'];
$city = $_REQUEST['city'];
$state = $_REQUEST['state'];
$query = $obj->runQuery("UPDATE tbl_address SET contact_name=:name,mobile=:mobile,email=:email,street=:street,pincode=:pincode,city=:city,state=:state,landmark=:landmark WHERE a_id=:aid");
$run = $query->execute(array(':name' => $name,':mobile' => $mobile,':email' => $email,':street' =>$street,':pincode' =>$pincode,':city' =>$city,':state' =>$state,':landmark' =>$landmark,':aid' =>$aid)); 
if($run)
{
$msg = array(   
"status" => "true",
"message" => "Successfully Created !!"			
);     	 
//http_response_code(200);
echo json_encode($msg); 
}
else{
//http_response_code(400);
$msg = array(   
"status" => "false",
"message" => "Successfully Not Created !!"	
); 
echo json_encode($msg);
}        
    
  
