<?php
//header("Access-Control-Allow-Origin: *");
//header("Content-Type: application/json; charset=UTF-8");
include('config.php');
 
    $sql = $obj->runQuery("SELECT * FROM tbl_menu WHERE status='1' ORDER BY menu_id ASC");
    $sql->execute();
    $num = $sql->rowCount();
    if($num > 0){
        $categories_arr=array("status" => "true",
        "message" => "Successfully Created !!");
        $categories_arr["records"]=array();
      while($row = $sql->fetch(PDO::FETCH_ASSOC)){      
          extract($row);    
         
          $category_item=array(
            "id" => $menu_id,
            "name" => $menu_name          
        );
        array_push($categories_arr["records"], $category_item);
      }      
   // http_response_code(200); 
    echo json_encode($categories_arr);
    }
    else
    {
    //http_response_code(404); 
    echo json_encode(
        array("message" => "No categories found.")
    );
    }
?>