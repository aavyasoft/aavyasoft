<?php
include('config.php');
$mobile = $_REQUEST['mobile'];
$sql = $obj->runQuery("SELECT user_id,mobile FROM tbl_user WHERE mobile=:mobile");
$sql->execute(array(':mobile' => $mobile));
if ($sql->rowCount() > 0) {
    $msg = array(
        "status" => "false",
        "message" => "Mobile Exist !!"
    );
    echo json_encode($msg);
} else {

    $msg = array(
        "status" => "true",
        "message" => "Mobile Not Exist"
    );
    echo json_encode($msg);
}
