<?php
//header("Access-Control-Allow-Origin: *");
//header("Content-Type: application/json; charset=UTF-8");
include('config.php'); 

$id = $_REQUEST['id'];
$sql = "SELECT p.*,c.category from tbl_product AS p INNER JOIN tbl_category AS c ON c.cat_id=p.cat_id where p.p_id=:product";
$sql = $obj->runQuery($sql);
$sql->execute(array(':product'=>$id));
if($sql->rowCount() > 0) {
$row = $sql->fetch(PDO::FETCH_ASSOC);
  $sql1 = $obj->runQuery('SELECT image_name from tbl_product_image where p_id=:p_id LIMIT 1');
  $sql1->execute(array(':p_id'=>$row['p_id']));
  $row1 = $sql1->fetch(PDO::FETCH_ASSOC);
  $size = $obj->getoneval('tbl_size','size_name','size_id',$row['size_id']);
  $com_id = $obj->getoneval('tbl_product_composition','com_id','p_id',$row['p_id']);
  $manufacuter = ucfirst($obj->getoneval('tbl_company','company','company_id',$row['company_id']));
  $img = BASE_URL.'clickadmin/document/' .$row1['image_name'];
  $name = ucfirst($row['product']);
  $discount = $row['discount'];
  $mainprice = $row['price'];
  $price = (100-$discount)*($row['price']/100);
  $discountprice =  number_format((float)$price, 2, '.', '');
  $sizes = $row['size_desc'];
  $pid =  $row['p_id'];
  $qty = $row['quantity'];
  $short_desc = $row['short_desc'];
  $long_desc = $row['long_desc'];
$categories_arr=array(   
          "status" => "true",
          "message" => "Successfully Created !!",
          'id' => $pid,
          "manufacturer" => $manufacuter,
          "image" => $img,
          "name" => $name,
          "discount" => $discount,
          'mainprice' => $mainprice,
          "price" => $discountprice,
          "size" => $size,
          "sizedesc" => $sizes,
          "qty" => $qty,
          "shortdesc" => $short_desc,
         "longdesc" => strip_tags($long_desc)
        );
$categories_arr["compositions"]=array();
$categories_arr["releted"]=array();

  $sql2 = $obj->runQuery("SELECT c.* from tbl_composition AS c INNER JOIN tbl_product_composition AS pc ON pc.com_id=c.com_id INNER JOIN tbl_product AS p ON p.p_id=pc.p_id where pc.p_id=:p_id");
 $sql2->execute(array(':p_id'=>$row['p_id']));
 while($row2 = $sql2->fetch(PDO::FETCH_ASSOC)){
    $comps = $row2['composition'];
      $category_item=array(
            "composition" => $comps            
        );
    array_push($categories_arr["compositions"], $category_item);
 }
 $p_id = $row['p_id'];
          $sql12 = $obj->runQuery("SELECT p.* from tbl_product AS p INNER JOIN tbl_product_composition AS c ON c.p_id=p.p_id where c.p_id !=:p_id AND c.com_id =:com_id   ORDER BY p.price ASC LIMIT 10");
            $sql12->execute(array(':p_id'=>$row['p_id'],':com_id'=>$com_id));
             if($sql12->rowCount() > 0){
            while($row12 = $sql12->fetch(PDO::FETCH_ASSOC)){
                 $strlink = BASE_URL.'product/'.str_replace(' ','-',strtolower($row12['product']));
            
                  $qa = (int) filter_var($row['size_desc'], FILTER_SANITIZE_NUMBER_INT);
             $qaa = (int) filter_var($row12['size_desc'], FILTER_SANITIZE_NUMBER_INT);
                $myp = $row['price'] / (int)$qa; 
                $npr = $row12['price'] / (int)$qaa;
              
                $sc = $myp - $npr;
                $dp = $sc * 100 / $myp;
             // $al = $dp * 100 / $price;
              $val = round($dp);
             $str = explode(' ',$row12['size_desc']);
              $p = (100-$row12['discount'])*($row12['price']/100);
       // if($price > $p){ $val = round((($price-$p)/$p)*100,2);}else{$val =round((($price-$p)/$p)*100,2); }
        if($val > 0){
                 $sv = "Save"; 
              }
              else 
              {
                 $sv = "Pay";
              }
        
          if($val){
              
              $pname = $row12['product'];
               $pids = $row12['p_id'];
              $ssize = $row12['size_desc'];
              $cname = ucfirst($obj->getoneval('tbl_company','company','company_id',$row12['company_id']));
              $save =  $sv.' '.abs($val).'% More Per '.ucfirst($str[1]);
              $pp = number_format((float)$p, 2, '.', '');
              $category_itema=array(
            "pid" => $pids,
            "product" => $pname,            
            "size" => $ssize,
            "company" => $cname,
            "price" => $pp,
            "link" => $strlink,
            "save" => $save          
        );
        array_push($categories_arr["releted"], $category_itema);
          }
        }
    }

   // http_response_code(200); 
    echo json_encode($categories_arr);
}
else
{
     //http_response_code(404); 
    echo json_encode(
        array("status" => "false","message" => "No product found.")
    );
}
?>
