<?php
//header("Access-Control-Allow-Origin: *");
//header("Content-Type: application/json; charset=UTF-8");
include('config.php'); 

$id = $_REQUEST['id'];
$sql = "SELECT p.*,c.category from tbl_product AS p INNER JOIN tbl_category AS c ON c.cat_id=p.cat_id where p.p_id=:product";
$sql = $obj->runQuery($sql);
$sql->execute(array(':product'=>$id));
if($sql->rowCount() > 0) {
$row = $sql->fetch(PDO::FETCH_ASSOC);
  $sql1 = $obj->runQuery('SELECT image_name from tbl_product_image where p_id=:p_id LIMIT 1');
  $sql1->execute(array(':p_id'=>$row['p_id']));
  $row1 = $sql1->fetch(PDO::FETCH_ASSOC);
  $size = $obj->getoneval('tbl_size','size_name','size_id',$row['size_id']);
  $com_id = $obj->getoneval('tbl_product_composition','com_id','p_id',$row['p_id']);
  $manufacuter = ucfirst($obj->getoneval('tbl_company','company','company_id',$row['company_id']));
  $img = BASE_URL.'clickadmin/document/' .$row1['image_name'];
  $name = ucfirst($row['product']);
  $discount = $row['discount'];
  $mainprice = $row['price'];
  $price = (100-$discount)*($row['price']/100);
  $discountprice =  number_format((float)$price, 2, '.', '');
  $size = $row['size_desc'];
  $pid =  $row['p_id'];
  $qty = $row['quantity'];
  $short_desc = $row['short_desc'];
  $long_desc = $row['long_desc'];
$categories_arr=array(   
          "status" => "true",
          "message" => "Successfully Created !!"        
        );

$categories_arr["releted"]=array();


 $p_id = $row['p_id'];
          $sql12 = $obj->runQuery("SELECT p.* from tbl_product AS p INNER JOIN tbl_product_composition AS c ON c.p_id=p.p_id where c.p_id !=:p_id AND c.com_id =:com_id   ORDER BY p.price ASC LIMIT 10");
            $sql12->execute(array(':p_id'=>$row['p_id'],':com_id'=>$com_id));
            while($row12 = $sql12->fetch(PDO::FETCH_ASSOC)){
             if($sql12->rowCount() > 0){
              $p = (100-$row12['discount'])*($row12['price']/100);
        if($price > $p){ $val = round((($price-$p)/$p)*100,2);}else{$val =round((($price-$p)/$p)*100,2); }
          if($val > 0){
               $sizea = $obj->getoneval('tbl_size','size_name','size_id',$row12['size_id']);
              $pname = $row12['product'];
               $pids = $row12['p_id'];
              $ssize = $row12['size_desc'];
              $cname = ucfirst($obj->getoneval('tbl_company','company','company_id',$row12['company_id']));
              $save = round($val/$row12['quantity'],2).'% more per tablet';
              $pp = number_format((float)$p, 2, '.', '');
              $category_itema=array(
            "pid" => $pids,
            "product" => $pname, 
            "sizedesc" => $ssize,
            "size" => '1 '. $sizea,
            "company" => $cname,
            "price" => $pp,
            "save" => $save           
        );
        array_push($categories_arr["releted"], $category_itema);
          }
        }
    }

    //http_response_code(200); 
    echo json_encode($categories_arr);
}
else
{
     //http_response_code(404); 
    echo json_encode(
        array("status" => "false","message" => "No product found.")
    );
}
?>
