<?php
//header("Access-Control-Allow-Origin: *");
//header("Content-Type: application/json; charset=UTF-8");
include('config.php');
 
    $sql = $obj->runQuery("SELECT * FROM tbl_company ORDER BY company ASC");
    $sql->execute();
    $num = $sql->rowCount();
    if($num > 0){
        $categories_arr=array();
        $categories_arr["records"]=array();
      while($row = $sql->fetch(PDO::FETCH_ASSOC)){
      	$stmt = $obj->runQuery("SELECT count(p_id) AS total FROM tbl_product WHERE company_id=:company_id");
      	$stmt->execute(array(':company_id'=>$row['company_id']));
          $row1 = $stmt->fetch(PDO::FETCH_ASSOC);
          extract($row);
          extract($row1);          
          $category_item=array(
            "id" => $company_id,
            "name" => $company,
            "count" => $total
        );
        array_push($categories_arr["records"], $category_item);
      }      
   // http_response_code(200); 
    echo json_encode($categories_arr);
    }
    else
    {
   // http_response_code(404); 
    echo json_encode(
        array("message" => "No categories found.")
    );
    }
?>