<?php
//header("Access-Control-Allow-Origin: *");
//header("Content-Type: application/json; charset=UTF-8");
include('config.php');
  $id = $_REQUEST['id'];
    $sql = $obj->runQuery("SELECT * FROM tbl_prescription WHERE user_id=:user_id ORDER BY presc_id DESC");
    $sql->execute(array(':user_id'=>$id));
    $num = $sql->rowCount();
    if($num > 0){
        $categories_arr=array("status" => "true",
        "message" => "Successfully Created !!");
        $categories_arr["records"]=array();
      while($row = $sql->fetch(PDO::FETCH_ASSOC)){      
          extract($row);  
         
      $dt = date('d-m-Y',strtotime($cdate)); 
       $imglink = BASE_URL.'image/prescription/'.$prescription_img;
         
          $category_item=array(
            'uid' => $id,
            "id" => $presc_id,
            "img" => $imglink,
            "date" => $dt,
            "days" => $days
        );
        array_push($categories_arr["records"], $category_item);
      }      
   // http_response_code(200); 
    echo json_encode($categories_arr);
    }
    else
    {
    echo json_encode(
        array("status" => "false","message" => "No categories found")
    );
    }
?>