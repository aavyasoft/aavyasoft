<?php
//header("Access-Control-Allow-Origin: *");
//header("Content-Type: application/json; charset=UTF-8");
//header("Access-Control-Allow-Methods: PUT, GET, POST");
include('config.php');
$uid = $_REQUEST['id']; 
$days = $_REQUEST['days'];
$r = rand(100,1000);    
$fimage = $r.time().$_FILES['prescription']['name'];  
$temp_name=$_FILES['prescription']['tmp_name'];
if (!empty($_FILES['prescription']['name'])){
$query = $obj->runQuery("INSERT INTO tbl_prescription SET user_id=:id,prescription_img=:name,days=:days");
$run = $query->execute(array(':id' =>$uid,':name' => $fimage,':days' => $days));
$lid = $obj->lastid();
$obj->compress($temp_name, "../click4drug/image/prescription/".$fimage, 50); 
if($run)
{
$msg = array(   
"status" => "true",
"message" => "Successfully Created !!",
"data" => array(
				"uid" => $uid,
				"presc_id" => $lid,
				"days" => $days				
			)			
);     	 
//http_response_code(200);
echo json_encode($msg); 
}
else{
$msg = array(   
"status" => "false",
"message" => "Successfully Not Created !!",
"data" => array()
); 
echo json_encode($msg);
} 	
}
else
{
$msg = array(   
"status" => "false",
"message" => "Successfully Not Created !!",
"data" => array()
); 
echo json_encode($msg);

}

