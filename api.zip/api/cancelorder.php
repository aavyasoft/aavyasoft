<?php
include('config.php');
$uid = $_REQUEST['uid'];
$order = $_REQUEST['orderid'];
$remark = $_REQUEST['remark'];
$cdate = date('Y-m-d');
$query = $obj->runQuery("UPDATE tbl_order SET c_remark=:remark,c_date=:cdate,status=:st WHERE order_id=:orderid AND user_id=:uid");
$run = $query->execute(array(':remark' => $remark, ':cdate' => $cdate, ':st' => '3', ':orderid' => $order, ':uid' => $uid));
if ($run) {
    $msg = array(
        "status" => "true",
        "message" => "Successfully Created !!"
    );

    echo json_encode($msg);
} else {

    $msg = array(
        "status" => "false",
        "message" => "Successfully Not Created !!"
    );
    echo json_encode($msg);
}
