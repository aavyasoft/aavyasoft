<?php
include('config.php');
$uid = $_REQUEST['uid']; 
$name = $_REQUEST['name'];
$email = $_REQUEST['email'];
$mobile = $_REQUEST['mobile'];
$street = $_REQUEST['street'];
$landmark = $_REQUEST['landmark'];
$pincode = $_REQUEST['pincode'];
$city = $_REQUEST['city'];
$state = $_REQUEST['state'];
$query = $obj->runQuery("INSERT INTO tbl_address SET user_id=:id,contact_name=:name,mobile=:mobile,email=:email,street=:street,pincode=:pincode,city=:city,state=:state,landmark=:landmark");
$run = $query->execute(array(':id' =>$uid,':name' => $name,':mobile' => $mobile,':email' => $email,':street' =>$street,':pincode' =>$pincode,':city' =>$city,':state' =>$state,':landmark' =>$landmark)); 
$lid = $obj->lastid();
if($run)
{
$msg = array(   
"status" => "true",
"message" => "Successfully Created !!",
"aid" => $lid
);     	 
http_response_code(200);
echo json_encode($msg); 
}
else{
http_response_code(400);
$msg = array(   
"status" => "false",
"message" => "Successfully Not Created !!"	
); 
echo json_encode($msg);
}        
    
  
