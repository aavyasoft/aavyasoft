<?php
error_reporting(0);
include('config.php');
$pid = $_REQUEST['pid'];
$pim = $obj->getoneval('tbl_prescription','prescription_img','presc_id',$pid); 
$query = $obj->runQuery("DELETE FROM tbl_prescription WHERE presc_id=:pid");
$run = $query->execute(array(':pid' => $pid)); 
//unlink('../click4drug/image/prescription/'.$pim); 
if($run)
{
$msg = array(   
"status" => "true",
"message" => "Successfully Created !!"
);
echo json_encode($msg); 
}
else{
$msg = array(   
"status" => "false",
"message" => "Successfully Not Created !!"
); 
echo json_encode($msg);
}        
    
  
