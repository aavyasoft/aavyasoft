<?php
include('config.php');
$uid = $_REQUEST['uid'];
$query = $obj->runQuery("DELETE FROM temp_cat WHERE uid=:uids");
$run = $query->execute(array(':uids' =>$uid)); 
if($run)
{
$msg = array(   
"status" => "true",
"message" => "Successfully Created !!"			
);     	 
//http_response_code(200);
echo json_encode($msg); 
}
else{
//http_response_code(400);
$msg = array(   
"status" => "false",
"message" => "Successfully Not Created !!"	
); 
echo json_encode($msg);
}        
    
  
