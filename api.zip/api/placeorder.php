<?php
//header("Access-Control-Allow-Origin: *");
//header("Content-Type: application/json; charset=UTF-8");
include('config.php');
   $id = $_REQUEST['id'];
   $aid = $_REQUEST['aid'];
   $pmode = $_REQUEST['paymentmode'];
    $total = 0;
   $sql = $obj->runQuery("SELECT * FROM temp_cat WHERE uid=:id");
    $sql->execute(array(':id' => $id));
    $num = $sql->rowCount();  
        while($row = $sql->fetch(PDO::FETCH_ASSOC))
        {
         extract($row);
          $squery = $obj->runQuery("SELECT * FROM tbl_product WHERE p_id=:pid");
        $squery->execute(array(':pid' => $p_id));
        $scol = $squery->fetch(PDO::FETCH_ASSOC);
         extract($scol);
          $discountprice = (100-$discount)*($price/100);
          $discountprice =  number_format((float)$discountprice, 2, '.', '');
          $subtotal =  $discountprice * $qty;
          $total += $subtotal;
        }
        if($total > 300)
        {
            $shipping = 0;
        }
        else
        {
            $shipping = 30;
        }
        $mtotal = $total +  $shipping;
        
    $query = $obj->runQuery("INSERT INTO tbl_order(user_id,a_id,amount,shipping_charge,t_amount,payment_type,cdate,status,order_type) VALUES(:userid,:aid,:amount,:shipping,:tamount,:pay,:cdate,:st,:otype)");
    $query->execute(array(':userid' => $_REQUEST['id'],':aid' => $aid,':amount' =>$total, ':shipping' => $shipping, ':tamount' =>$mtotal,':pay' => $pmode,':cdate' => date('Y-m-d'), ':st' => '1',':otype' => '1'));
    $lid = $obj->lastid();
    if($lid > 0)
    {      
        $ssql = $obj->runQuery("SELECT * FROM temp_cat WHERE `uid`=:ids");
        $ssql->execute(array(':ids' => $_REQUEST['id']));
        while($col = $ssql->fetch(PDO::FETCH_ASSOC))
        {
            
            $ssquery = $obj->runQuery("SELECT * FROM tbl_product WHERE p_id=:pid");
        $ssquery->execute(array(':pid' => $col['p_id']));
        $sscol = $ssquery->fetch(PDO::FETCH_ASSOC);       
            $mysql = $obj->runQuery("INSERT INTO tbl_order_details(order_id,p_id,quantity,rate,discount_p) VALUES (:orderid,:pid,:qty,:rate,:discount)");
           $run = $mysql->execute(array(':orderid' => $lid,':pid' =>$col['p_id'],':qty' => $col['qty'],':rate' => $sscol['price'],':discount' => $sscol['discount']));
        }
        if(@$run)
        {
            $myquery = $obj->runQuery("DELETE FROM temp_cat WHERE `uid`=:uid");
            $myquery->execute(array(':uid' => $_REQUEST['id']));            
               $msg = array(   
			"status" => "true",
			"message" => "Successfully Created !!",          
			"data" => array(
				"orderid" => $lid				
			)
		 );     	 
          //http_response_code(200);
           echo json_encode($msg); 
        }
        else{
            //http_response_code(400);
		   $msg = array(   
			"status" => "false",
			"message" => "Successfully Not Created !!"	
		 ); 
           echo json_encode($msg);
        }
        
    }
    
