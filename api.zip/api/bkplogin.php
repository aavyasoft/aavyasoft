<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
 
// database connection will be here
include('config.php');
$json = json_decode(file_get_contents("php://input"));

$sql = $obj->runQuery("SELECT * from tbl_user where mobile=:mobile");
$sql->execute(array(':mobile'=>$json->mobile));
if($sql->rowCount() > 0){
    $row = $sql->fetch(PDO::FETCH_ASSOC);
      if($row['status'] == 1){
           if($row['password'] == $json->password){ 
            $token = array(   
              "status" => "true",
              "message" => "Successfully Login !!",          
              "data" => array(
                  "id" => $row['user_id'],
                  "uname" => $row['uname'],
                  "mobile" => $row['mobile'],
                  "email" => $row['email']
              )
           );             
               // set response code
              http_response_code(200);
              echo json_encode($token);
       
              
           }else{               
               http_response_code(400);   
              $msg = array(   
			"status" => "false",
			"message" => "Password Error !!"	
		 ); 
           echo json_encode($msg);
           }
      }else{
        http_response_code(400);   
       $msg = array(   
			"status" => "false",
			"message" => "Block !!"	
		 ); 
           echo json_encode($msg);          
      }
}else{
    
    http_response_code(400);   
    $msg = array(   
			"status" => "false",
			"message" => "Mobile Error !!"	
		 ); 
           echo json_encode($msg); 
}