<?php
//header("Access-Control-Allow-Origin: *");
//header("Content-Type: application/json; charset=UTF-8");
include('config.php');
   $id = $_REQUEST['id'];
   $aid = $_REQUEST['aid'];
   $days = $_REQUEST['days'];
   $presc_id = $_REQUEST['presc_id'];
   $pmode = '0';
    $total = 0;
     $shipping = 0;
     $mtotal = 0;
        
    $query = $obj->runQuery("INSERT INTO tbl_order(user_id,a_id,presc_id,days,amount,shipping_charge,t_amount,payment_type,cdate,status,order_type) VALUES(:userid,:aid,:prid,:da,:amount,:shipping,:tamount,:pay,:cdate,:st,:otype)");
   $run = $query->execute(array(':userid' => $_REQUEST['id'],':aid' => $aid, ':prid' =>$presc_id, ':da' =>$days, ':amount' =>$total, ':shipping' => $shipping, ':tamount' =>$mtotal,':pay' => $pmode,':cdate' => date('Y-m-d'), ':st' => '0',':otype' => '2'));
    $lid = $obj->lastid();  
        if($run)
        {
                      
            $msg = array(   
			"status" => "true",
			"message" => "Successfully Created !!",          
			"data" => array(
				"orderid" => $lid				
			)
		 );     	 
          //http_response_code(200);
           echo json_encode($msg); 
        }
        else{           
		   $msg = array(   
			"status" => "false",
			"message" => "Successfully Not Created !!"	
		 ); 
           echo json_encode($msg);
        }
        

    
