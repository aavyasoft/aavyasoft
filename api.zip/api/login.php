<?php 
// database connection will be here
include('config.php');
$mobile = $_REQUEST['mobile'];
 $password = $_REQUEST['password']; 

$sql = $obj->runQuery("SELECT * from tbl_user where mobile=:mobile");
$sql->execute(array(':mobile'=>$mobile));
if($sql->rowCount() > 0){
    $row = $sql->fetch(PDO::FETCH_ASSOC);
      if($row['status'] == 1){
           if($row['password'] == $password){ 
            $token = array(   
              "status" => "true",
              "message" => "Successfully Login !!",          
              "data" => array(
                  "id" => $row['user_id'],
                  "uname" => $row['uname'],
                  "mobile" => $row['mobile'],
                  "email" => $row['email']
              )
           );             
               // set response code
              //http_response_code(200);
              echo json_encode($token);
       
              
           }else{               
              // http_response_code(400);   
              $msg = array(   
			"status" => "false",
			"message" => "Password Error !!"
		
		 ); 
           echo json_encode($msg);
           }
      }else{
        //http_response_code(400);   
       $msg = array(   
			"status" => "false",
			"message" => "Block !!"
		 ); 
           echo json_encode($msg);          
      }
}else{
    
    //http_response_code(400);   
    $msg = array(   
			"status" => "false",
			"message" => "Mobile Error !!"
		 ); 
           echo json_encode($msg); 
}