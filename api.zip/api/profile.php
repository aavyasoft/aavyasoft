<?php
//header("Access-Control-Allow-Origin: *");
//header("Content-Type: application/json; charset=UTF-8");
include('config.php'); 
$id = $_REQUEST['id'];
$sql = $obj->runQuery("SELECT * FROM tbl_user WHERE user_id=:id");
$sql->execute(array(':id' => $id));
$num = $sql->rowCount();
if($num > 0){
    $row = $sql->fetch(PDO::FETCH_ASSOC);
     $sql1 = $obj->runQuery("SELECT * FROM tbl_address WHERE user_id=:user_id");
     $sql1->execute(array(':user_id'=>$id));
     if($sql1->rowCount() > 0)
     {
     $row1 = $sql1->fetch(PDO::FETCH_ASSOC);
     extract($row1);
     }
     else
     {
         $contact_name = "";
         $mobile ="";
         $email = "";
         $street ="";
         $pincode ="";
         $city ="";
         $state ="";
         $landmark ="";
         $country ="";
     }
    extract($row);
   
      
    $categories_arr=array(   
        "status" => "true",
        "message" => "Successfully Created !!",
        "data" => array(
            "id" => $user_id,
            "uname" => $uname,
            "mobile" => $mobile,
            "email" => $email,
            "contact_name" => $contact_name,
            "mobile" => $mobile,
            "email" => $email,
            "street" => $street,
            "pincode" => $pincode,
            "city" => $city,
            "state" => $state,
            "landmark" => $landmark,
            "country" => $country 
        )
    );        
   // http_response_code(200); 
    echo json_encode($categories_arr);
}
else
{
   // http_response_code(404); 
    echo json_encode(
        array("message" => "No categories found.")
    );

}
?>
