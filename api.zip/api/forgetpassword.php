<?php
include('config.php');
$mobile = $_REQUEST['mobile'];
$sql = $obj->runQuery("SELECT user_id,mobile FROM tbl_user WHERE mobile=:mobile");
$sql->execute(array(':mobile'=>$mobile));
if($sql->rowCount() > 0){
    $msg1 = rand(9999,1111);
    $row = $sql->fetch(PDO::FETCH_ASSOC); 
    $mobileno = $row['mobile'];          		
			  $authKey = "5a3d7c4056c7399b2fca28fc2e36beb9";               
                $mobileNumber = "$mobileno";                
                $senderId = "CFDOFR";               
                $message = ("$msg1 is Your 4 Digit One Time Password For Mobile Verification");              
                $route = "4";              
                $postData = array(
                    'authkey' => $authKey,
                    'mobiles' => $mobileNumber,
                    'message' => $message,
                    'sender' => $senderId,
                    'route' => $route
                );              
                $url = "http://sms.bulksmsserviceproviders.com/api/send_http.php";              
                $ch = curl_init();
                curl_setopt_array($ch, array(
                    CURLOPT_URL => $url,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_POST => true,
                    CURLOPT_POSTFIELDS => $postData                
                ));               
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);              
                $output = curl_exec($ch);              
                if (curl_errno($ch)) {    
                }
                curl_close($ch);

                $query = $obj->runQuery("UPDATE tbl_user SET otp=:otp WHERE user_id=:uids");
                $query->execute(array(':otp' => $msg1,':uids' => $row['user_id']));
             $token = array(   
              "status" => "true",
              "message" => "Successfully Send !!",          
              "data" => array(
                  "id" => $row['user_id'],                
                  "mobile" => $row['mobile']                
              )
           ); 
        echo json_encode($token);
  
}else{   
    
    $msg = array(   
			"status" => "false",
			"message" => "Mobile Error"	
		 ); 
           echo json_encode($msg); 
}
