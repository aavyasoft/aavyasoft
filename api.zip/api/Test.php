<?php
class TEST
{
	
	//public $id;
   // public $cancel;

       function __construct($DB_con)
	    {
	      $this->db = $DB_con;
	    }

	    public function runQuery($sql)
		{
		  $stmt = $this->db->prepare($sql);
		    return $stmt;
		}
		public function getoneval($tbl,$columnname,$column,$id)
		 {
		  $stmt = $this->db->prepare("SELECT {$columnname} FROM {$tbl} WHERE {$column}=:id");
		  $stmt->execute(array(":id"=>$id));
		  $row = $stmt->fetch(PDO::FETCH_ASSOC);
		  return $row[$columnname];
		 } 
		public function lastid()
		{
		    $stmt = $this->db->lastInsertId();
		    return $stmt;
		} 
	    public function update($tbl,$field,$condition){
	    	$col = '';
	    	$i = 0;
	    	$y = 0;
	    	$cond = '';
	    	//$where = 'WHERE';
	    	
	    	 foreach($field as $key=>$val){
	    	 	$pre = ($i > 0)?', ':'';
	    	 	$col .= $pre.$key." =:".$key;
	    	 	$i++;
	    	 }
	    	 
	    	 foreach ($condition as $key => $value) {
	    		$pre = ($y > 0)?' AND ':'';
	    		$cond .= $pre.$key.' =:'.$key;
	    		$y++;
	    	}
	    	 $rec = array_merge($field,$condition);
		      $sql = " UPDATE {$tbl} set ".$col." WHERE ".$cond;
		      $stmt = $this->db->prepare($sql);
		      if($stmt->execute($rec)){
		        return true;
		    }
	 
	    		return false;

   		}
   	public function insert($tbl,$data){
   		$col = '';
        $i = 0;
        $val = '';
        $col1 = '';
         foreach ($data as $key => $value) {
            $pre = ($i > 0)?', ':'';           
            $col .= $pre.$key;
            $col1 .= $pre.':'.$key;            
            $i++;
         }
   		$sql = " INSERT into {$tbl} (".$col.")  VALUES (".$col1.")"; 
   		 $stmt = $this->db->prepare($sql);
		      if($stmt->execute($data)){
		        return true;
		    }
	 
	    		return false;

   	}	

   public function delete($tbl,$condition){
   			$y = 0;
	    	$cond = '';
   			foreach ($condition as $key => $value) {
	    		$pre = ($y > 0)?' AND ':'';
	    		$cond .= $pre.$key." =:".$key;
	    		$y++;
	    	}
	    $sql = " DELETE FROM {$tbl} WHERE ".$cond;
	    $stmt = $this->db->prepare($sql);
		      if($stmt->execute($condition)){
		        return true;
		    }
	 
	    		return false;	
   }
   public function view($tbl,$field){
        $sql = " SELECT ".$field." FROM {$tbl} ";
	    $stmt = $this->db->prepare($sql);
		$stmt->execute();
		$row = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $row;	
   }
   public function get_by_id($tbl,$field,$condition){
   			$y = 0;
	    	$cond = '';
   			foreach ($condition as $key => $value) {
	    		$pre = ($y > 0)?' AND ':'';
	    		$cond .= $pre.$key." =:".$key;
	    		$y++;
	    	}
	    $sql = " SELECT ".$field." FROM {$tbl} WHERE ".$cond;
	    $stmt = $this->db->prepare($sql);
		$stmt->execute($condition);
		return $stmt ;		 	
   }
public function convertinword($number){
	
    $decimal = round($number - ($no = floor($number)), 2) * 100;
    $hundred = null;
    $digits_length = strlen($no);
    $i = 0;
    $str = array();
    $words = array(0 => '', 1 => 'one', 2 => 'two',
        3 => 'three', 4 => 'four', 5 => 'five', 6 => 'six',
        7 => 'seven', 8 => 'eight', 9 => 'nine',
        10 => 'ten', 11 => 'eleven', 12 => 'twelve',
        13 => 'thirteen', 14 => 'fourteen', 15 => 'fifteen',
        16 => 'sixteen', 17 => 'seventeen', 18 => 'eighteen',
        19 => 'nineteen', 20 => 'twenty', 30 => 'thirty',
        40 => 'forty', 50 => 'fifty', 60 => 'sixty',
        70 => 'seventy', 80 => 'eighty', 90 => 'ninety');
    $digits = array('', 'hundred','thousand','lakh', 'crore');
    while( $i < $digits_length ) {
        $divider = ($i == 2) ? 10 : 100;
        $number = floor($no % $divider);
        $no = floor($no / $divider);
        $i += $divider == 10 ? 1 : 2;
        if ($number) {
            $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
            $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
            $str [] = ($number < 21) ? $words[$number].' '. $digits[$counter]. $plural.' '.$hundred:$words[floor($number / 10) * 10].' '.$words[$number % 10]. ' '.$digits[$counter].$plural.' '.$hundred;
        } else $str[] = null;
    }
    $Rupees = implode('', array_reverse($str));
    $paise = ($decimal > 0) ? " " . ($words[$decimal / 10] . " " . $words[$decimal % 10]) . ' Paise' : '';
    return ($Rupees ? $Rupees . 'Rupees ' : '') . $paise;
 } 

	 function dateDiffInDays($date1, $date2)  
	 { 
	    
	    $diff = strtotime($date2) - strtotime($date1);	    
	    return abs(round($diff / 86400)); 
	 } 
	 
	function compress($source, $destination, $quality) {

          $info = getimagesize($source);

          if ($info['mime'] == 'image/jpeg') 
              $image = imagecreatefromjpeg($source);

          elseif ($info['mime'] == 'image/gif') 
              $image = imagecreatefromgif($source);

          elseif ($info['mime'] == 'image/png') 
              $image = imagecreatefrompng($source);

          imagejpeg($image, $destination, $quality);

          return $destination;
    }
}
?>