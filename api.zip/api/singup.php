<?php
include('config.php');
$uname = $_REQUEST['cname']; 
	$email = $_REQUEST['email']; 
	$mobile = $_REQUEST['mobile'];
	$password = $_REQUEST['password'];
	
	$data1 = array(
 		'uname' => $uname,
 		'mobile' => $mobile,
 		'email' => $email,	
 		'password' => $password 						
 	);
 	
 $sql = $obj->runQuery("SELECT * from tbl_user where mobile=:mobile OR email=:email");
 $sql->execute(array(':mobile'=>$mobile,':email'=>$email)) ;
	if($sql->rowCount() > 0){
     $row = $sql->fetch(PDO::FETCH_ASSOC);
     if($row['mobile'] == $mobile && $row['email'] == $email){
        //http_response_code(400);
        $msg = array(   
			"status" => "false",
			"message" => "Both Exist !!",
				"data" => ""
		 ); 
           echo json_encode($msg); 		 
    }elseif($row['mobile'] == $mobile){     
     // http_response_code(400);
	  $msg = array(   
		"status" => "false",
		"message" => "Mobile Exist !!",
			"data" => ""
	 ); 
	   echo json_encode($msg); 
    }elseif($row['email'] == $email){
		//http_response_code(400);
		$msg = array(   
			"status" => "false",
			"message" => "Email Exist !!",
				"data" => ""); 
           echo json_encode($msg);      
    }
	}else{
	   if($obj->insert('tbl_user',$data1)){
		   $user_id = $obj->lastid(); 
		   $msg = array(   
			"status" => "true",
			"message" => "Successfully Created !!",          
			"data" => array(
				"id" => $user_id,
				"uname" => $uname,
				"mobile" => $mobile,
				"email" => $email
			)
		 );     	 
          //http_response_code(200);
           echo json_encode($msg); 		 
		}else{		   
		   //http_response_code(400);
		   $msg = array(   
			"status" => "false",
			"message" => "Successfully Not Created !!",
			"data" => ""
		 ); 
           echo json_encode($msg); 
           
		 }
	}