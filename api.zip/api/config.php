<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
define('BASE_URL',"http://www.click4drug.in/click4drug/");
$DB_host = "localhost";
$DB_user = "click4drug";
$DB_pass = "?l6A_oIN3b3M";
$DB_name = "click4drug";
try
{
     $DB_con = new PDO("mysql:host={$DB_host};dbname={$DB_name}",$DB_user,$DB_pass);
     $DB_con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e)
{
    $e->getMessage();
}

include_once 'Test.php';
$obj = new TEST($DB_con);

?>

