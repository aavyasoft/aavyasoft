<?php
//header("Access-Control-Allow-Origin: *");
//header("Content-Type: application/json; charset=UTF-8");
include('config.php'); 
    $sql = $obj->runQuery("SELECT p.*,c.category,sc.sub_category FROM tbl_product AS p INNER JOIN tbl_category AS c ON c.cat_id=p.cat_id INNER JOIN tbl_sub_category AS sc ON sc.sub_cat_id=p.sub_cat_id ORDER BY p_id DESC LIMIT 20");
    $sql->execute();
    $num = $sql->rowCount();
    if($num > 0){
        $categories_arr=array();
        $categories_arr["records"]=array();
      while($row = $sql->fetch(PDO::FETCH_ASSOC)){
      	$stmt = $obj->runQuery("SELECT image_name FROM tbl_product_image WHERE p_id=:p_id");
      	$stmt->execute(array(':p_id'=>$row['p_id']));
          $row1 = $stmt->fetch(PDO::FETCH_ASSOC);
          $size = $obj->getoneval('tbl_size','size_name','size_id',$row['size_id']);
          extract($row);
          extract($row1);
          $strlink = BASE_URL.'product/'.str_replace(' ','-',strtolower($product));
          $imglink = BASE_URL.'clickadmin/document/'.$image_name;
          $productname = substr($product, 0, 15);
          $discountprice = round((100-$discount)*$price/100,2);
          $category_item=array(
            "id" => $p_id,
            "name" => $productname,
            "mainprice" => $price,
            "discount" => $discount,
            "discountprice" => $discountprice,
            "size" => $size,
            "link" => $strlink,
            "img" => $imglink
        );
        array_push($categories_arr["records"], $category_item);
      }      
    //http_response_code(200); 
    echo json_encode($categories_arr);
    }
    else
    {
    //http_response_code(404); 
    echo json_encode(
        array("message" => "No categories found.")
    );
    }
?>