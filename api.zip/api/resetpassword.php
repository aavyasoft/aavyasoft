<?php
include('config.php');
$id = $_REQUEST['id'];
$newpass = $_REQUEST['password'];
//$otps =   $_REQUEST['otps'];
$sql = $obj->runQuery("UPDATE tbl_user SET password=:pass WHERE user_id=:uids");
$run = $sql->execute(array(':pass' => $newpass,':uids'=>$id));
if($run){    
      
             $token = array(   
              "status" => "true",
              "message" => "Successfully Change Password!!",          
              "data" => array(
                  "id" => $id       
                                
              )
           ); 
        echo json_encode($token);
  
}else{   
    
    $msg = array(   
			"status" => "false",
			"message" => "Successfully Not Change Password!!"	
		 ); 
           echo json_encode($msg); 
}
