<?php
//header("Access-Control-Allow-Origin: *");
//header("Content-Type: application/json; charset=UTF-8");
include('config.php'); 
 $search = $_GET["term"];
  $categories_arr=array("status" => "true",
        "message" => "Successfully Created !!");
        $categories_arr["records"]=array();
 // $return_arr = array();

  //$abc = array();

$sql = $obj->runQuery("SELECT p.*,c.category,sc.sub_category from tbl_product AS p INNER JOIN tbl_category AS c ON c.cat_id=p.cat_id INNER JOIN tbl_sub_category AS sc ON sc.sub_cat_id=p.sub_cat_id where p.product LIKE :pname OR category LIKE :cname OR sub_category LIKE :sname ");

$sql->execute(array(':pname'=>'%'.strtoupper($search).'%',':cname'=>'%'.strtoupper($search).'%',':sname'=>'%'.strtoupper($search).'%'));

  if ($sql->rowCount() > 0 ) {

        while($row = $sql->fetch(PDO::FETCH_ASSOC))

          {
            $image = $obj->getoneval('tbl_product_image','image_name','p_id',$row['p_id']);
            $abc['id'] = $row['p_id'];

            $abc['value'] = $row['product'];

             //$abc['label'] = '<div><span style="width:575px;">&nbsp;'.$row['product'].' (<strong style="font-size:12px;color:#ff0000">'.$row['size_desc'].'</strong>)</span><span style="width:110px;"><strong style="font-size:12px;">MRP ₹'.round($row['price']).'</strong></span></div>';

            $abc['cat'] = str_replace(' ','-',strtolower($row['product']));
            array_push($categories_arr["records"], $abc);
            //array_push($return_arr, $abc);

          }
      }

  echo json_encode($categories_arr);
  ?>
