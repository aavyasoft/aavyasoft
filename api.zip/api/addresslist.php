<?php
//header("Access-Control-Allow-Origin: *");
//header("Content-Type: application/json; charset=UTF-8");
include('config.php');
   $uid = $_REQUEST['id'];
    $sql = $obj->runQuery("SELECT * FROM tbl_address WHERE user_id=:userid ORDER BY a_id DESC");
    $sql->execute(array(':userid' => $uid));
    $num = $sql->rowCount();
    if($num > 0){
        $categories_arr=array( "status" => "true",
          "message" => "Successfully Created !!");
        $categories_arr["records"]=array();
      while($row = $sql->fetch(PDO::FETCH_ASSOC)){      	
          extract($row);        
        
          $category_item=array(
            "id" => $a_id,
            "name" => $contact_name,
            "mobile" => $mobile,
            "email" => $email,
            "street" => $street,
            "pincode" => $pincode,
            "city" => $city,
            "state" => $state,
            "landmark" => $landmark,
            "country" => $country
        );
        array_push($categories_arr["records"], $category_item);
      }      
    //http_response_code(200); 
    echo json_encode($categories_arr);
    }
    else
    {
    //http_response_code(404); 
    echo json_encode(
        array("status" => "true","message" => "Successfully Created !!", "records" =>array())
    );
    }
?>
