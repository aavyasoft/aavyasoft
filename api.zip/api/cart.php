<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
include('config.php');
$id = $_REQUEST['uid']; 
    $sql = $obj->runQuery("SELECT * FROM temp_cat WHERE uid=:id");
    $sql->execute(array(':id' => $id));
    $num = $sql->rowCount();
    if($num > 0)
    {
        $total = 0;
        $mtotal = 0;
         $categories_arr=array(   
          "status" => "true",
          "message" => "Successfully Created !!");
        $categories_arr["records"]=array();
        while($row = $sql->fetch(PDO::FETCH_ASSOC))
        {
        extract($row);
        $stmt = $obj->runQuery("SELECT image_name FROM tbl_product_image WHERE p_id=:p_id");
      	$stmt->execute(array(':p_id'=>$p_id));
        $row1 = $stmt->fetch(PDO::FETCH_ASSOC);
        $query = $obj->runQuery("SELECT * FROM tbl_product WHERE p_id=:pid");
        $query->execute(array(':pid' => $p_id));
        $col = $query->fetch(PDO::FETCH_ASSOC);
        extract($col);
        extract($row1);        
        $size = $obj->getoneval('tbl_size','size_name','size_id',$size_id);    
         $strlink = BASE_URL.'product/'.str_replace(' ','-',strtolower($product));
          $imglink = BASE_URL.'clickadmin/document/'.$image_name;
          $productname = substr($product, 0, 15);
          $discountprice = (100-$discount)*($price/100);
          $prices = number_format((float)$price, 2, '.', '');
          $discountprice =  number_format((float)$discountprice, 2, '.', '');
          $mtotal +=  $prices * $qty;
          $subtotal =  $discountprice * $qty;
          $total += $subtotal;
          $category_item=array(
            "id" => $p_id,
            "name" => $productname, 
            "mainprice" => $prices,
            "price" => $discountprice,
            'qty' => $qty,
            'subtotal' => number_format((float)$subtotal, 2, '.', ''),
            "size" => $size,  
            "sizedesc" => ucfirst($size_desc),
            "img" => $imglink          

        );
        array_push($categories_arr["records"], $category_item);   
        }
         $save =  $mtotal-  $total;
        $mtotal =  number_format((float)$mtotal, 2, '.', '');
        $total =  number_format((float)$total, 2, '.', '');
        $save =  number_format((float)$save, 2, '.', '');
        $categories_arrs=array("total" => $mtotal,"save" => $save,"tobepaid" => $total);
        // $categories_arrsss=array("save" => $save);
        // $categories_arrs=array("tobepaid" => $total);
       $marr =  array_merge($categories_arr,$categories_arrs);
    //   $marr =  array_merge($categories_arr,$categories_arrss);
    //   $marr =  array_merge($categories_arr,$categories_arrsss);
//http_response_code(200); 
    echo json_encode($marr);
    }
    else
    {
         //http_response_code(404); 
        echo json_encode(
        array("status" => "true","message" => "Successfully Created !!","records" => array())
    );
        
    }
