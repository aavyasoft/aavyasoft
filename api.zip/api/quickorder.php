<?php
  include('config.php'); 
  $medicine = $_POST['medicine'];
  $quantity =  $_POST['quantity'];
  $name = $_POST['name'];
  $mobile = $_POST['mobile'];
  $email = $_POST['email'];
  $pincode = $_POST['pincode'];
  $address = $_POST['address'];
  $valid_extensions = array('jpeg', 'jpg', 'png');
  $imagecheck = 0;
  $data = array('uname'=>$name,'mobile'=>$mobile,'email'=>$email,'pincode'=>$pincode,'address'=>$address);
  if($obj->insert('tbl_quick_order',$data)){
    $q_id = $obj->lastid();
    $count = count($_POST['medicine']);
    for($i=0; $i < $count; $i++){ 
       if (!empty($_FILES['image']['name'][$i])){
             $imgFile = $_FILES['image']['name'][$i];
             $imgExt = strtolower(pathinfo($imgFile,PATHINFO_EXTENSION));     
            if(in_array($imgExt, $valid_extensions)){
              $r = rand(100,1000);    
              $fimage = $r.time().$_FILES['image']['name'][$i];
              $temp_name=$_FILES['image']['tmp_name'][$i];
              $imagecheck = 1;
              $data1 = array('q_id'=>$q_id,'medicine'=>$medicine[$i],'quantity'=>$quantity[$i],'image1'=>$fimage);
           }else{
              $data1 = array('q_id'=>$q_id,'medicine'=>$medicine[$i],'quantity'=>$quantity[$i]);
           }
      }
      else{
        $data1 = array('q_id'=>$q_id,'medicine'=>$medicine[$i],'quantity'=>$quantity[$i]);
      }
        if($obj->insert('tbl_quick_details',$data1)){
            if($imagecheck == 1){
            // $obj->compress($temp_name, "../click4drug/image/prescription/".$fimage, 60);
           }
         
        }
    }
    $msg = array(   
"status" => "true",
"message" => "Successfully Created !!",
"data" => array(
				"uid" => $q_id						
			)			
);
    
  }
  else{    
   $msg = array(   
"status" => "false",
"message" => "Successfully Not Created !!"	
); 
}
echo json_encode($msg);
  
?>
