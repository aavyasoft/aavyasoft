<?php
//header("Access-Control-Allow-Origin: *");
//header("Content-Type: application/json; charset=UTF-8");
include('config.php');
 
    $sql = $obj->runQuery("SELECT * FROM tbl_sub_category WHERE status='1' AND cat_id=:cat");
    $sql->execute(array(':cat' => $_REQUEST['id']));
    $num = $sql->rowCount();
    if($num > 0){
        $categories_arr=array("status" => "true",
        "message" => "Successfully Created !!");
        $categories_arr["records"]=array();
      while($row = $sql->fetch(PDO::FETCH_ASSOC)){      
          extract($row);    
         
          $category_item=array(
             "id" => $cat_id,
            "sid" => $sub_cat_id ,
            "name" => $sub_category          
        );
        array_push($categories_arr["records"], $category_item);
      }      
    //http_response_code(200); 
    echo json_encode($categories_arr);
    }
    else
    {
         $categories_ar=array("status" => "false",
        "message" => "No categories found !!");
        $categories_ar["records"]=array();       
    //http_response_code(404); 
     echo json_encode($categories_ar);
    }
?>
