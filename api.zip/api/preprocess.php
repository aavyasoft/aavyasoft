<?php
include('config.php');
$uid = $_REQUEST['id'];
if(isset($_REQUEST['order']) && !empty($_REQUEST['order'])){
    $presc_id = $obj->getoneval('tbl_order','presc_id','order_id',$_REQUEST['order']);
    $sql = $obj->runQuery("SELECT * FROM tbl_prescription WHERE presc_id=:presc_id ORDER BY presc_id DESC LIMIT 1");
  $sql->execute(array(':presc_id'=>$presc_id));
  $row = $sql->fetch(PDO::FETCH_ASSOC);
  }
  else {
  $sql = $obj->runQuery("SELECT * FROM tbl_prescription WHERE user_id=:user_id ORDER BY presc_id DESC LIMIT 1");
  $sql->execute(array(':user_id'=>$uid));
  $row = $sql->fetch(PDO::FETCH_ASSOC);
  } 

$msg = array(   
			"status" => "true",
			"message" => "Successfully Created !!",          
			"data" => array(
				"id" => $uid,
				"presc_id" => $row['presc_id'],
				"days" => $days				
			)
		 );     	 
//http_response_code(200);
echo json_encode($msg); 
  ?>