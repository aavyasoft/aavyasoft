<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
include('config.php');
$total = 0;
$mtotal = 0;
$tqty = 0;
$orderid = $_REQUEST['orderid'];
$mysql = $obj->runQuery("SELECT * FROM tbl_order WHERE order_id=:userid");
$mysql->execute(array(':userid' => $orderid));
$col = $mysql->fetch(PDO::FETCH_ASSOC);
$shipping = $col['shipping_charge'];
if($col['status'] == '1')
{
   $ostatus = 'Pending'; 
}
elseif($col['status'] == '2')
{
 $ostatus = 'Deliverd';    
}
elseif($col['status'] == '3')
{
 $ostatus = 'Cancel';    
}
elseif($col['status'] == '4')
{
 $ostatus = 'Refund Request';    
}
elseif($col['status'] == '5')
{
 $ostatus = 'Refund Accept';    
}
else
{
  $ostatus = '';  
}
$query = $obj->runQuery("SELECT * FROM tbl_address WHERE a_id=:aid");
$query->execute(array(':aid' => $col['a_id']));
$mycol = $query->fetch(PDO::FETCH_ASSOC);



$sql = $obj->runQuery("SELECT * FROM tbl_order_details WHERE order_id=:userid");
$sql->execute(array(':userid' => $orderid));
$num = $sql->rowCount();
if ($num > 0) {
  $categories_arr = array(
    "status" => "true",
    "message" => "Successfully Created !!",
    "orderstatus" => $ostatus,
    "name" => $mycol['contact_name'],
    "mobile" => $mycol['mobile'],
    "email" => $mycol['email'],
    "street" => $mycol['street'],
    "pincode" => $mycol['pincode'],
    "city" => $mycol['city'],
    "state" => $mycol['state'],
    "landmark" => $mycol['landmark'],
    "country" => $mycol['country']
  );
  $categories_arr["records"] = array();
  while ($row = $sql->fetch(PDO::FETCH_ASSOC)) {
    extract($row);
    $discountprice = (100 - $discount_p) * ($rate / 100);
    $mtotal +=  $rate * $quantity;
    $subtotal =  $discountprice * $quantity;
    $total += $subtotal;
    $tqty += $quantity;
    $productname = $obj->getoneval('tbl_product', 'product', 'p_id', $p_id);
     $discountprice =  number_format((float)$discountprice, 2, '.', '');
    $category_item = array(
      "product" => $productname,
      "Quantity" => $quantity,
      "Price" => $rate,
      "Discount" => $discountprice,
      "subtotal" => number_format((float)$subtotal, 2, '.', '')
    );
    array_push($categories_arr["records"], $category_item);
  }
  $save =  $mtotal -  $total;
  $mtotal =  number_format((float)$mtotal, 2, '.', '');
  $total =  number_format((float)$total, 2, '.', '');
  $save =  number_format((float)$save, 2, '.', '');
  $categories_arrs = array("total" => $mtotal, "save" => $save, "tobepaid" => $total, "totalqty" => $tqty, "shipping" => $shipping);
  $marr =  array_merge($categories_arr, $categories_arrs);
  //http_response_code(200);
  echo json_encode($marr);
} else {
  //http_response_code(404);
  echo json_encode(
    array("status" => "false", "message" => "No address found.")
  );
}
