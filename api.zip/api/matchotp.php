<?php
include('config.php');
$mobile = $_REQUEST['mobile'];
$otps =   $_REQUEST['otps'];
$sql = $obj->runQuery("SELECT user_id,mobile FROM tbl_user WHERE mobile=:mobile AND otp=:otp");
$sql->execute(array(':mobile'=>$mobile,':otp' => $otps));
if($sql->rowCount() > 0){    
    $row = $sql->fetch(PDO::FETCH_ASSOC);     
             $token = array(   
              "status" => "true",
              "message" => "Successfully Match otp !!",          
              "data" => array(
                  "id" => $row['user_id'],                
                  "mobile" => $row['mobile']                
              )
           ); 
        echo json_encode($token);
  
}else{   
    
    $msg = array(   
			"status" => "true",
			"message" => "Otp Error"	
		 ); 
           echo json_encode($msg); 
}
